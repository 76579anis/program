﻿// For more information see https://aka.ms/fsharp-console-apps
printfn "Hello from Anisha"
printfn "Hello from Divya"
open System
let square x = x*x
let cube x = x*x*x
let sign x = 
          if x>0 then "positive"
          else if x<0 then "negative"
          else "zero"
          
let passFive f = (f 5)
printfn "%A" (passFive square)
printfn "%A" (passFive cube)
printfn "%A" (passFive sign)

let iseven x = 
       if x % 2 =0 then "even"
       else "odd"
printfn "The number 4 is %s"(iseven 4)
printfn "The number 7 is %s"(iseven 7)
let checksign x = 
        if x>0 then "positive"
        else if x<0 then "negative"
        else "zero"
printfn "The number 5 is %s" (checksign 5)
printfn "The number 3 is %s" (checksign 3)
printfn "The number 0 is %s" (checksign 0)

let double = fun x -> x*2 // this is lambda function 
let x = double 5
printfn "%A" x
let multiplybytwo x = x*2
let dividebytwo x = x/2
let addtwo x = x+2
printfn "10 is multiply by 2 is %d" (multiplybytwo 10)
printfn "20 is divide by 2 is %d" (dividebytwo 20 )
printfn "2 is add by 2 is %d" (addtwo 2)
let curriedadd x y = x+y //donot need bracket for parameters
printfn "%A" (curriedadd 5 10)
let toupledadd (x,y) = x+y
printfn "%A" (toupledadd (10,5))
let greet hour = 
            if hour <12 then "Good Morning"
            else if hour <18 then "good afternoon"
            else "good evening"
printfn "%s" (greet 10)
printfn "%s" (greet 14)
printfn "%s" (greet 20)

let Something x y =
      let doublex = x*2
      let doubley = y*2
      doublex+doubley
      
let value = Something 5 6
printfn "%A" value

// pipe operation our operation is working from left to right or right to left
let print x = 
    printfn "%s" x
"Hello my name is Anisha" |> print //pipe symbol |> or <|
print <| "Hello my name is Anisha"
//chainnig function using pipe function
let doublex x = x*2
let triplex x= x*3
let increasebyone x = x+1

let answer = 10 |> increasebyone |> doublex |> triplex

printfn "%A" (answer)
//compose operator >> code is pending for this operation

let test1 x = 
    let test2 a = a*a
    let test3 a = a*a*a
    if x=2 then test2
    else test3
let divya = test1 2
printfn "%A" (divya 1) // if we pass another parameter the we it will work other wise it will not work 

let rec recursion n =
    if n <= 1 then
        n
    else
        n + recursion (n - 1)
 
let a = recursion 10
printfn "%A" a

let rec factorial x =
   if x < 1 then 1
   else
     x * factorial(x-1)

let res = factorial(6)
printfn "%A" res

let Numberarray = [|1;2;3;4|]
printfn "%A" Numberarray
printfn "%A" Numberarray.[0] //to print the first number into array we have || lines to find out array
let newarray = Array.append Numberarray [|11;12;13|]
printfn "%A" Numberarray
printfn "%A" newarray

let list = [1 .. 5]
for i in list do // for i is for each 
printfn "%d" i

let inventory = [ "Apples", 0.33; "Oranges", 0.23; "Bananas", 0.45 ] |> Map.ofList
 
// Use tryFind to safely get the value for a key that may not exist
let apples = 
    match Map.tryFind "Apples" inventory with
    | Some price -> price
    | None -> 0.0 // Default or fallback value if "Apples" doesn't exist
 
let pineapples = 
    match Map.tryFind "Pineapples" inventory with
    | Some price -> price
    | None -> 0.0 // Default or fallback value if "Pineapples" doesn't exist
 
// Add a new item "Pineapples" and remove "Apples" from the map
let newInventory = 
    inventory 
    |> Map.add "Pineapples" 0.87 
    |> Map.remove "Apples"
 
// Optional: Print results to verify
printfn "Apples price: %f" apples
printfn "Pineapples price: %f" pineapples
printfn "Updated Inventory: %A" newInventory

let x = fun n -> n*n
let square = [2;3;4;5] |> List.map x
printfn "%A" square

let g = fun (s : string) -> s.Length
let newList = ["five"; "six"; "pick up"; "sticks"]
let lengths = newList |> List.map g
printfn "%A" lengths


let something = [4;5;6;7] // iter  it will print value into one by one

something |> List.iter (printfn "%A")

let something = [4;5;6;7]
something |> List.iter (printfn "%A")
let newList = something |> List.collect (fun x -> [1..x])
printfn "%A" newList

//lab1
let power exponent value = pown value exponent
let result = power 3 4
printfn "Result of 4 raised to the power of 3: %d" result


let power exponent value = pown value exponent

// Use partial application to create square and cube functions
let square = power 2
let cube = power 3

// Values to test
let value1 = 5
let value2 = 3

// Apply square and cube functions to the values
let squareOfValue1 = square value1
let squareOfValue2 = square value2

let cubeOfValue1 = cube value1
let cubeOfValue2 = cube value2

// Print the results
printfn "Square of %d: %d" value1 squareOfValue1
printfn "Square of %d: %d" value2 squareOfValue2
printfn "Cube of %d: %d" value1 cubeOfValue1
printfn "Cube of %d: %d" value2 cubeOfValue2

let values = [2; 3; 4] // Example values

let squareResults = values |> List.map square
let cubeResults = values |> List.map cube

printfn "Square results: %A" squareResults
printfn "Cube results: %A" cubeResults

//lab1

let rec product list accumulator =
    match list with
    | [] -> accumulator
    | head :: tail -> product tail (accumulator * head)

// Test the function
let result = product [1; 2; 3; 4; 5;6] 1
printfn "Product of elements: %d" result


let rec calcOddProduct n accumulator =
    if n <= 0 then accumulator
    else calcOddProduct (n - 2) (accumulator * n)

// Test the function
let oddResult = calcOddProduct 11 1
printfn "Product of odd numbers: %d" oddResult

//Using Map Function with a Collection:
let names = [" Charles"; "Babbage  "; "  Von Neumann  "; "  Dennis Ritchie  "]
let cleanedNames = names |> List.map (fun name -> name.Trim())

// Print the cleaned names
cleanedNames |> List.iter (printfn "%s")

//Using Filter and Reduce with a Collection:
let numbers = [1..700]
let multiples = numbers |> List.filter (fun x -> x % 7 = 0 && x % 5 = 0)
let total = multiples |> List.sum
printfn "Sum of multiples: %d" total

//Using Filter and Reduce with Collection of Strings:
let names = ["James"; "Robert"; "John"; "William"; "Michael"; "David"; "Richard"]

// Filter names containing 'M' or 'c' and concatenate them
let concatenatedNames = 
    names
    |> List.filter (fun name -> name.Contains("M") || name.Contains("c"))
    |> List.fold (fun acc name -> acc + name) ""

// Output the concatenated result
printfn "Concatenated names: %s" concatenatedNames



